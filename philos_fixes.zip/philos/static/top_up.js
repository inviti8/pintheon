document.addEventListener('init', function(event) {
    let page = event.target;

});
